import React from "react";
import styled from "styled-components";
import AveragePatientChart from "../../components/superAdmin/dashboard/Charts/AveragePatientChart";
import PatientStatisticChart from "../../components/superAdmin/dashboard/Charts/PatientStatisticChart";
import Header from "../../components/Header";
import Sider from "../../components/Sider";
import EarningChart from "../../components/superAdmin/dashboard/Charts/EarningChart";
import Cards from "../../components/Accountant/Cards";

const Dashboard = () => {
  return (
    <Wrapper>
      <Header />
      <div className="main">
        <div className="container-fluid">
          <div className="row flex-nowrap ">
            <div className="col-xxl-1 col-xl-1 col-lg-1 col-md-2 col-sm-10 p-0">
              <Sider />
            </div>
            <div className="col-xxl-11 col-xl-11 col-lg-11 col-md-10 col-sm-10">
              <div className="row d-flex justify-content-between">
                <div className="col-12 col-md-4 mt-4">
                  <div>
                    <h5>Branch : Madan Mahal</h5>
                  </div>
                  <div className="mt-2">
                    <h3> Welcome to Dental Guru! </h3>
                  </div>
                  <div className="mt-3">
                    <h6>Accountant Dashboard</h6>
                  </div>
                </div>

                <div className="col-12 col-md-4 me-2 mt-5">
                  <form className="d-flex ms-auto my-sm" role="search">
                    <input
                      className="form-control me-2"
                      type="search"
                      placeholder="Search"
                      aria-label="Search"
                    />
                    <button
                      className="btn btn-primary"
                      style={{ backgroundColor: "#201658" }}
                      type="submit"
                    >
                      Search
                    </button>
                  </form>
                </div>
              </div>

              <div className="d-flex justify-content-center mt-4">
                <h2> TODAY`S OVERVIEW</h2>
              </div>

              <div className="mt-4">
                <Cards />
              </div>

              <div className="container px-4 me-5">
                <div className="row g-5 mt-3 ">
                  <div className="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                    <h3 className="text-center">Annual INCOME & EXPENCE</h3>
                    <AveragePatientChart />
                  </div>

                  <div className="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                    <h3 className="text-center">EARNING REPORT</h3>
                    <EarningChart />
                  </div>

                  <div className="col-xxl-8 col-xl-8 col-lg-8 col-md-8 col-sm-6 col-6">
                    <h3 className="text-center ">CALENDAR</h3>
                    <div className="h-250vh">
                      <PatientStatisticChart />
                    </div>
                  </div>

                  <div className="col-xxl-4 col-xl-4 col-lg-4 col-md-4 col-sm-6 col-6">
                    <h3 className="text-center mt-1">LIST OF DEPARTMENTS </h3>

                    <table class="table mt-4">
                      <tbody>
                        <tr>
                          <td className="text-center table-info fw-bolder">
                            Accountant
                          </td>
                        </tr>
                        <tr>
                          <td className="text-center table-secondary fw-bolder">
                            Doctors
                          </td>
                        </tr>
                        <tr>
                          <td className="text-center table-success fw-bolder">
                            Lab Attander
                          </td>
                        </tr>
                        <tr>
                          <td className="text-center table-danger fw-bolder">
                            Pharmacist
                          </td>
                        </tr>
                        <tr>
                          <td className="text-center table-warning fw-bolder">
                            Receptionist
                          </td>
                        </tr>
                        <tr>
                          <td className="text-center table-primary fw-bolder">
                            Other
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Wrapper>
  );
};

export default Dashboard;

const Wrapper = styled.div`
  .main {
    height: 100%;
    background-color: #e6ecf1;
  }
  .chart {
    background-color: white;
    border-radius: 5px;
  }
  #hd {
    height: 44rem;

    @media screen and (max-width: 768px) {
      height: 68rem;
    }
    @media screen and (min-width: 768px) and (max-width: 1020px) {
      height: 58rem;
    }
  }

  .clinic-act-heading {
    display: flex;
    justify-content: space-between;
  }
`;
