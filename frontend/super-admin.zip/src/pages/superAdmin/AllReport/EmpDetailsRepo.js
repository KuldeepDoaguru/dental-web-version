import React from "react";
import styled from "styled-components";

const EmpDetailsRepo = () => {
  return (
    <>
      <Container>
        <h1>Hello</h1>
      </Container>
    </>
  );
};

export default EmpDetailsRepo;
const Container = styled.div``;
